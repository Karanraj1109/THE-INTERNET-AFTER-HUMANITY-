# The Internet After Humanity

A premium interactive web concept / portfolio piece. Static front-end prototype.

## Run
Open `index.html` directly in a browser, or serve the folder with any static server.

## Concept
Set in 2126, 37 years after human internet activity went silent. Visitors explore surviving archives, a repeating signal, a reconstructed chronology, and an archivist that appears to remember them.

## Notes
No backend is required for this prototype. The next version could connect archive objects, authentication, persistent messages, real-time state, a database, and an AI archivist.
